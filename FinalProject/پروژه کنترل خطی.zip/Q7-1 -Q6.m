clc
clear
close all

s= tf('s')
G=(-5.4)*(s-2)*(0.6*s+1)*3.86/((s^3)+0.96*s^2+9*s)
bode(G)