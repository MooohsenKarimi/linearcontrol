dataFile = 'Data.mat';
load(dataFile);  

freq = Data.omega;        
magResponse = Data.magnitude;   
phaseResponse = Data.phase; 

mag_dB = 20 * log10(magResponse);

fig = figure;

subplot(2,1,1);
semilogx(freq, mag_dB, 'LineWidth', 2, 'Color', [0 0 1]); 
xlabel('Frequency (rad/s)', 'FontSize', 12);
ylabel('Magnitude (dB)', 'FontSize', 12);
title('Bode Diagram - Magnitude', 'FontSize', 14);
grid on;

subplot(2,1,2);
semilogx(freq, phaseResponse, 'LineWidth', 2, 'Color', [1 0 0]); 
xlabel('Frequency (rad/s)', 'FontSize', 12);
ylabel('Phase (degrees)', 'FontSize', 12);
title('Bode Diagram - Phase', 'FontSize', 14);
grid on;

saveas(fig, 'Bode_Response.png');  
saveas(fig, 'Bode_Response.fig');  

dataFile = 'Data.mat';
load(dataFile);

freq = Data.omega;  
ampResponse = Data.magnitude;  
phaseResponse = Data.phase; 
radfhase=deg2rad(phaseResponse);
Magnitu=ampResponse.*exp(1i*radfhase);
mohsen=frd(Magnitu,freq);
systemIdentification

figure('Color', 'w', 'Position', [200, 200, 800, 600]);

subplot(2,1,1);
plot(freq, ampResponse, 'g--o', 'LineWidth', 1.8, 'MarkerSize', 4);  
xlabel('Frequency (rad/s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Magnitude', 'FontSize', 12, 'FontWeight', 'bold');
title('Linear Frequency Response - Magnitude', 'FontSize', 14, 'FontWeight', 'bold');
grid on;

subplot(2,1,2);
plot(freq, phaseResponse, 'm-.s', 'LineWidth', 1.8, 'MarkerSize', 4);  
xlabel('Frequency (rad/s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Phase (degrees)', 'FontSize', 12, 'FontWeight', 'bold');
title('Linear Frequency Response - Phase', 'FontSize', 14, 'FontWeight', 'bold');
grid on;

saveas(gcf, 'ModifiedFrequencyResponse.png');  
savefig(gcf, 'ModifiedFrequencyResponse.fig');  

  