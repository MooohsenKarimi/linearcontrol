s=tf('s');
G = (0.27*s-0.54)/(s^3+0.96*s^2+9*s);
Td=(-0.5*(s-2))/((s+1)^3);
Sd=(s^3+3*s^2+3.5*s)/((s+1)^3);
C=1.15*Td/(Sd*G);
LoopGain = C*G;
CloseLoop = feedback(LoopGain,1);
figure;
step(CloseLoop)
info = stepinfo(CloseLoop);
Undershoot = info.Undershoot
settling_time = info.SettlingTime