clc
clear
close all
num=[0.27 -0.54];
den=[1 0.9 9 0];
sys= tf(num,den);
rlocus(sys)
hold on
rlocus(-sys,'--')
set(findall(figure(1),'type','line'),'linewidth',2)
hold off
